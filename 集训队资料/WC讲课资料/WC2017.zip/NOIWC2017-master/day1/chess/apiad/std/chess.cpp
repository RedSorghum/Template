#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#define rep(i,a,n) for (int i=a;i<n;i++)
using namespace std;
typedef vector<int> VI;
#define pb push_back
const int N=110;
int n,p[N];

struct permutation{
	int a[N];
	bool is1(){ rep(i,1,n) if (a[i] != i) return false; return true; }
	void print() {
		rep(i,1,n) printf("%d ",a[i]); puts("");
	}
};
permutation operator*(permutation x, permutation y){
	rep(i,1,n) x.a[i] = y.a[x.a[i]];
	return x;
}
permutation inv(permutation x){
	permutation ret;
	rep(i,1,n) ret.a[x.a[i]] = i;
	return ret;
}

int idx, m, ls[N], rid[N][N], lr[N];
int b[N];
permutation s[N][N], r[N][N], rr[N][N];

int q[N];
bool vst[N];

void bfs(){
	int u=b[idx], v, lq=0, rq=1;
	q[1] = u;
	rep(i,1,n) vst[i] = 0; vst[u] = 1;
	rep(i,1,n) r[idx][i].a[1] = 0;
	rep(i,1,n) r[idx][u].a[i] = rr[idx][u].a[i] = i;
	lr[idx] = 1, rid[idx][1] = u;
	permutation t;
	while (lq++ != rq){
		u = q[lq];
		rep(i,1,ls[idx]+1) {
			t = r[idx][u]*s[idx][i];
			v = t.a[b[idx]];
			if (!vst[v]){
				vst[v] = 1;
				q[++rq] = v;
				r[idx][v] = t;
				rr[idx][v] = inv(t);
				rid[idx][++lr[idx]] = v;
			}
		}
	}
}
void sift(permutation &h){
	rep(i,idx+1,m+1) if (h.a[b[i]] != b[i]){
		if (r[i][h.a[b[i]]].a[1] == 0) return;
		h = h*rr[i][h.a[b[i]]];
	}
	return;
}

void work(){ 
	idx = m = 1;
	rep(i,1,ls[1]+1) rep(j,1,n) if (s[1][i].a[j] != j) b[1] = j;
	bfs();
	while (idx){
		permutation h;
		bool o=1;
		rep(i,1,lr[idx]+1){
			rep(j,1,ls[idx]+1){
				h = r[idx][rid[idx][i]]*s[idx][j];
				h = h*rr[idx][h.a[b[idx]]];
				sift(h);
				if (!h.is1()){ o = 0; break; }
			}
			if (!o) break;
		}
		if (o) --idx;
		else{
			if (++idx > m){
				ls[++m] = 0;
				rep(j,1,n) if (h.a[j] != j) b[m] = j;
			}
			s[idx][++ls[idx]] = h;
			bfs();
		}
	}
}
int M,Q,u,v,vis[N],t,f[N],g[N],ins[N];
VI e[N];
void dfs(int u,int f) {
	p[u]=f; vis[u]=1; ins[u]=1;
	for (int i=0;i<e[u].size();++i) {
		int v=e[u][i];
		if (v==f) continue;
		if (vis[v]) {
			if (!ins[v]) continue;
			++t;
			rep(i,0,n) s[1][t].a[i]=i;
			int w=u;
			while (p[w]!=v) {
				s[1][t].a[w]=p[w];
				w=p[w];
			}
			s[1][t].a[w]=u;
		} else {
			dfs(v,u);
		}
	}
	ins[u]=0;
}
int pos[N];
void ff(int *f) {
	int u=-1;
	rep(i,0,n) if (f[i]==0) u=i;
	while (u) {
		swap(f[u],f[p[u]]);
		u=p[u];
	}
	rep(i,0,n) pos[f[i]]=i;
	rep(i,0,n) f[i]=pos[i];
}
int main(){
	scanf("%d%d%d",&n,&M,&Q);
	while (M--) {
		scanf("%d%d",&u,&v); --u; --v;
		e[u].pb(v); e[v].pb(u);
	}
	dfs(0,-1);
	ls[1]=t;
	if (t) work();
	rep(i,0,n) scanf("%d",f+i);
	ff(f);
	rep(j,0,Q) {
		rep(i,0,n) scanf("%d",g+i);
		ff(g);
		permutation x;
		rep(i,1,n) x.a[f[i]]=g[i];
		if (t) sift(x);
		if (x.is1()) puts("Yes"); else puts("No");
	}
	return 0;
}

