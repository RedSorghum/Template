#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
struct per{
	int n,A[51];
	void scan(int N){
		n=N;
		for (int i=1;i<=n;i++) scanf("%d",&A[i]);
	}
	void print(){
		for (int i=1;i<=n;i++) cout<<A[i]<<" "; cout<<endl;
	}
}A,B,u,v;
per del(per K){
	for (int i=1;i<K.n;i++) K.A[i]=K.A[i+1]-1;
	K.n--; return K;
}
per inv(per K){
	B=K;
	for (int i=1;i<=K.n;i++) B.A[K.A[i]]=i;
	return B;
}
per operator * (const per &k1,const per &k2){
	B=k1;
	for (int i=1;i<=k1.n;i++) B.A[i]=k2.A[k1.A[i]];
	return B;
}
struct group{
	int n,pd[51],len;
	per A[1000],w[51];
	void clear(int N){
		n=N; len=0;
		memset(pd,0x00,sizeof pd);
		pd[1]=1; w[1].n=N;
		for (int i=1;i<=n;i++) w[1].A[i]=i;
	}
}x[51];
void insert1(per A,int n);
void insert2(per A,int n);
int test(per A,int n);
int test(per A,int n){
	if (n==0) return 1;
	int k1=A.A[1];
	if (x[n].pd[k1]==0) return 0;
	return test(del(A*x[n].w[k1]),n-1);
}
void insert1(per A,int n){
	if (test(A,n)) return;
//	cout<<"insert1 "<<n<<endl;
//	A.print();
	x[n].len++; x[n].A[x[n].len]=A;
	for (int i=1;i<=n;i++)
		if (x[n].pd[i]){
		//	x[n].w[i].print();
			insert2(inv(x[n].w[i])*A,n);
		}
}
void insert2(per A,int n){
//	cout<<"insert2 "<<n<<" "<<A.n<<endl;
//	A.print(); 
	if (A.n!=n) exit(0);
	int k1=A.A[1];
	if (x[n].pd[k1]==0){
		x[n].w[k1]=inv(A); x[n].pd[k1]=1;
		for (int i=1;i<=x[n].len;i++)
			insert2(A*x[n].A[i],n);
	} else{
	//	cout<<"mul"<<endl;
	//	A.print();
	//	x[n].w[k1].print();
	//	(A*x[n].w[k1]).print();
		insert1(del(A*x[n].w[k1]),n-1);
	}
}
struct bian{
	int next,point;
}b[300];
int p[60],len,n,m,father[60],d[60];
void ade(int k1,int k2){
	b[++len]=(bian){p[k1],k2}; p[k1]=len;
}
void add(int k1,int k2){
	ade(k1,k2); ade(k2,k1);
}
per get(int k1,int k2){
	per A; A.n=n;
	for (int i=1;i<=n;i++) A.A[i]=i;
	swap(A.A[k1],A.A[k2]);
	return A;
}
void insert(int k1,int k2){
//	cerr<<"insert "<<k1<<" "<<k2<<endl;
	per A=get(k1,k2);
	vector<int>x;
	while (k1!=k2){
	//	A.print(); 
		x.push_back(k1);
	//	cerr<<"swap "<<k1<<" "<<father[k1]<<endl;
		A=get(k1,father[k1])*A; k1=father[k1];
	}
	x.push_back(k2);
//	A.print();
	insert1(A,n); 
}
void dfs(int k1,int k2){
//	cerr<<"asd "<<k1<<" "<<k2<<endl;
	for (int i=p[k1];i!=-1;i=b[i].next){
		if (i==(k2^1)) continue;
		int j=b[i].point;
		if (d[j]==0){
			d[j]=d[k1]+1; father[j]=k1;
			dfs(j,i);
		} else if (d[j]<d[k1]) insert(k1,j);
	}
}
void getpath(int k1,int k2){
	vector<int>A,B;
	while (k1!=k2)
		if (d[k1]>d[k2]){
			A.push_back(k1); k1=father[k1];
		} else {
			B.push_back(k2); k2=father[k2];
		}
	A.push_back(k1);
	for (int i=B.size();i;i--) A.push_back(B[i-1]);
	for (int i=1;i<A.size();i++) u=u*get(A[i-1],A[i]);
}
void goup(per &A,int k1){
	while (k1!=1){
		swap(A.A[k1],A.A[father[k1]]);
		k1=father[k1];
	}
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	int q;
	scanf("%d%d%d",&n,&m,&q);  
	for (int i=1;i<=n;i++) x[i].clear(i);
	len=-1; memset(p,0xff,sizeof p);
	for (int i=1;i<=m;i++){
		int k1,k2; scanf("%d%d",&k1,&k2); add(k1,k2);
	}
	d[1]=1; dfs(1,-100);
	u.scan(n);
	for (int i=1;i<=n;i++) u.A[i]++;
	for (;q;q--){
		v.scan(n);
		for (int i=1;i<=n;i++) v.A[i]++;
		int k1=0,k2=0;
		for (int i=1;i<=n;i++){
			if (u.A[i]==1) k1=i;
			if (v.A[i]==1) k2=i;
		}
		goup(u,k1); goup(v,k2);
	//	u.print(); v.print();
		if (test(v*inv(u),n)) printf("Yes\n"); else printf("No\n");
	}
	return 0;
}
