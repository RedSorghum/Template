#include<iostream>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int u[1100],v[1100],t[1100],len,n=17,now;
void add(int k1,int k2){
	len++; u[len]=k1; v[len]=k2; t[len]=now;
}
int main(){
	freopen("sort9.out","w",stdout);
	now=1;
	for (int i=2;i<=n;i+=2) add(i,i+1);
	now=2;
	for (int i=2;i<=n;i+=4){
		add(i,i+2); add(i+1,i+3);
	}
	now=3;
	for (int i=2;i<=n;i+=8){
		add(i,i+4); add(i+1,i+5); add(i+2,i+6); add(i+3,i+7);
	}
	now=4;
	add(1,4); add(2,14); add(3,11); add(5,8);
	add(6,12); add(7,13); add(9,17); add(15,16);
	now=5;
	add(1,14); add(2,17); add(3,6); add(4,7);
	add(5,15); add(8,16); add(9,10); add(11,12);
	now=6;
	add(1,2); add(3,9); add(4,5); add(6,11);
	add(7,14); add(8,12); add(10,16); add(13,15);
	now=7;
	add(2,6); add(3,16); add(4,9); add(5,11);
	add(7,8); add(10,13); add(12,14);
	now=8;
	add(1,3); add(2,4); add(5,7); add(8,10); 
	add(6,9); add(11,12); add(13,15); add(14,16);
	now=9;
	add(1,2); add(3,4); add(5,6); add(7,9);
	add(10,12); add(8,11); add(13,14); add(15,16);
	now=10;
	for (int i=2;i<=n;i+=2) add(i,i+1);
	printf("%d\n",len);
	for (int i=1;i<=len;i++)
		printf("%d %d %d\n",u[i],v[i],t[i]);
	return 0;
}
	
