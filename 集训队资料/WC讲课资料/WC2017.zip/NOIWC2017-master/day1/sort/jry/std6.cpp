#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int len,A[110000],n,m,K;
int u[5000000],v[5000000],t[5000000],a[5000];
int build(int l,int r){
	if (l==r) return 0;
	int mid=l+r>>1;
	int num=max(build(l,mid),build(mid+1,r))+1;
	len++; u[len]=a[mid]; v[len]=a[r]; t[len]=num;
	return num;
}
void down(int l,int r,int d){
	if (l==r) return; int mid=l+r>>1;
	len++; u[len]=a[mid]; v[len]=a[r]; t[len]=d;
	down(l,mid,d+1);
	down(mid+1,r,d+1);
}
void solve(){
	scanf("%d%d%d",&K,&n,&m); len=0;
	for (int j=1;j<=K;j++)
		for (int i=1;i<=n;i++){
			int k1; scanf("%d",&k1);
			if (i==n) a[j]=k1;
		}
	sort(a+1,a+K+1);
	if (a[K]==n) K--;
	int now=build(1,K);
	now++; len++; u[len]=a[K]; v[len]=n; t[len]=now;
	down(1,K,now+1);
	printf("%d\n",len); cerr<<len<<endl;
	for (int i=1;i<=len;i++) printf("%d %d %d\n",u[i],v[i],t[i]); 
}
int main(){
	freopen("sort6.mid","r",stdin);
	freopen("sort6.out","w",stdout);
	int t; scanf("%d",&t);
	for (;t;t--){
		cerr<<t<<endl; solve();
	}
	return 0;
}
