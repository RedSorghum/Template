#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
int tt,n,m,K,a[110000],aim[110000];
int u[1000000],v[1000000],t[1000000],len,pre,tot;
vector<int>A,B;
int merge(vector<int>A,vector<int>B,int d){
//	cerr<<"asd "<<A.size()<<" "<<B.size()<<endl;
	if (A.size()==0||B.size()==0) return d-1;
	if (A.size()==1&&B.size()==1){
	//	cout<<"fa "<<endl; 
		len++; u[len]=A[0]; v[len]=B[0]; t[len]=d; return d;
	}
	vector<int>a,b,c,D;
	for (int i=0;i<A.size();i++)
		if (i&1) b.push_back(A[i]); else a.push_back(A[i]);
	for (int i=0;i<B.size();i++)
		if (i&1) D.push_back(B[i]); else c.push_back(B[i]);
	if (A.size()%2) swap(c,D);
//	cerr<<a.size()<<" "<<b.size()<<" "<<c.size()<<" "<<D.size()<<endl;
	d=max(merge(a,c,d),merge(b,D,d))+1;
//	cerr<<"merge "<<d<<" "<<len<<endl;
	for (int i=0;i<c.size();i++) a.push_back(c[i]);
	for (int i=0;i<D.size();i++) b.push_back(D[i]);
	if (A.size()%2){
		if (b.size()<1) d--;
		for (int i=0;i<b.size();i++){
			len++; u[len]=a[i]; v[len]=b[i]; t[len]=d;
		}
	} else {
		if (a.size()<=1) d--;
		for (int i=1;i<a.size();i++){
			len++; u[len]=b[i-1]; v[len]=a[i]; t[len]=d;
		}
	}
	return d;
}
int build(int l,int r){
	if (l==r) return 0; 
	int mid=l+r>>1;
	int d=max(build(l,mid),build(mid+1,r))+1;
	A.clear(); B.clear();
	for (int i=l;i<=mid;i++) A.push_back(i);
	for (int i=mid+1;i<=r;i++) B.push_back(i);// cerr<<l<<" "<<r<<endl;
	d=merge(A,B,d); //cerr<<"fin "<<l<<" "<<r<<" "<<d<<endl; 
	return d;
}
void solve(){
	scanf("%d%d%d",&K,&n,&m); cerr<<K<<" "<<n<<" "<<m<<endl;
	len=0; pre=0;
	for (;K;K--){
		for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	}
	cerr<<"asd"<<endl;
	build(1,n);
	printf("%d\n",len);
	for (int i=1;i<=len;i++) printf("%d %d %d\n",u[i],v[i],t[i]);
}
int main(){
	freopen("sort8.mid","r",stdin);
	freopen("sort8.out","w",stdout);
	scanf("%d",&tt); //tt=1;
	for (;tt;tt--) solve();
	return 0;
}
