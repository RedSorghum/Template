#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int t,n,m,K,a[110000],aim[110000],A[110000];
void solve(){
	scanf("%d%d%d",&K,&n,&m);
	memset(aim,0x00,sizeof aim);
	for (int i=1;i<=n;i++) A[i]=i;
	for (;K;K--){
		for (int i=1;i<=n;i++){
			scanf("%d",&a[i]); 
			if (a[i]!=i) A[a[i]]=i;
		}
	}
	for (int i=1;i<=n;i++) if (A[A[i]]!=i) cerr<<"asd"<<endl;
	int tot=0;
	for (int i=1;i<=n;i++) if (A[i]<i) tot++;
	printf("%d\n",tot);
	for (int i=1;i<=n;i++)
		if (A[i]<i) printf("%d %d 1\n",A[i],i);
}
int main(){
	freopen("sort1.in","r",stdin);
	freopen("sort1.out","w",stdout);
	scanf("%d",&t);
	for (;t;t--) solve();
	return 0;
}
