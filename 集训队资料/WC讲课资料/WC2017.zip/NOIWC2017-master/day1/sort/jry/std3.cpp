#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int tt,n,m,K,a[110000],aim[110000],A[110000];
int u[1000000],v[1000000],t[1000000],len;
void solve(int l,int r,int t1){
	if (l==r) return;
	int mid=(l+r)>>1;
	int k1=l,k2=r;
	while (1){
		while (k1<=mid&&A[k1]<=mid) k1++;
		while (k2>mid&&A[k2]>mid) k2--;
		if (k1<=mid){
			len++; u[len]=k1; v[len]=k2; t[len]=t1;
			swap(A[k1],A[k2]);
		} else break;
	}
	solve(l,mid,t1+1);
	solve(mid+1,r,t1+1);
}
void solve(){
	scanf("%d%d%d",&K,&n,&m);
	for (int i=1;i<=n;i++) scanf("%d",&A[i]);
	len=0;
	solve(1,n,1);
	printf("%d\n",len);
	for (int i=1;i<=len;i++) printf("%d %d %d\n",u[i],v[i],t[i]);
}
int main(){
	freopen("sort3.mid","r",stdin);
	freopen("sort3.out","w",stdout);
	scanf("%d",&tt);
	for (;tt;tt--) solve();
	return 0;
}
