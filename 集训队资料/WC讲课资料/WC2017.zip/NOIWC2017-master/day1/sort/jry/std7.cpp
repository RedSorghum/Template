#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int len,A[110000],n,m,K;
int u[5000000],v[5000000],t[5000000];
int prebuild(int l,int r){
	if (l==r) return 0;
	int num=0;
	int mid=l+r>>1;
	if (l==r){
		num=1;
	} else {
		num=max(prebuild(l,mid),prebuild(mid+1,r))+1;
	}
	if (r==n) return num-1;
	len++; u[len]=mid+1; v[len]=r+1; t[len]=num;
	return num;
}
void buildtree(int l,int r,int d){
	if (l==r) return;
	int mid=l+r>>1;
	len++; u[len]=l; v[len]=mid+1; t[len]=d;
	buildtree(l,mid,d+1);
	buildtree(mid+1,r,d+1);
}
void solve(){
	scanf("%d%d%d",&K,&n,&m); len=0;
	cerr<<K<<" "<<n<<" "<<m<<endl;
	buildtree(1,n,prebuild(1,n)+1);
	for (;K;K--)
		for (int i=1;i<=n;i++){
			int k1; scanf("%d",&k1);
		}
	printf("%d\n",len); cerr<<len<<endl;
	for (int i=1;i<=len;i++) printf("%d %d %d\n",u[i],v[i],t[i]); 
}
int main(){
	freopen("sort7.mid","r",stdin);
	freopen("sort7.out","w",stdout);
	int t; scanf("%d",&t);
	for (;t;t--){
		cerr<<t<<endl; solve();
	}
	return 0;
}
