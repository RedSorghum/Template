#include<iostream>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int ne[110000],pd[110000],pre[110000],K,n,m,ans[110000],A[110000];
int check(int k1,int k2){
	if (k1==k2) return 1;
	if (k1>k2) swap(k1,k2);
	return ne[k1]>ne[k2];
}
void getans(int K){
	int size=0; 
	for (int i=K;pd[i]==0;i=ne[i]){
		size++; pd[i]=1;
	}
	int fir=K; int num=0;
	for (int now=1;now<=size;now++){
		int flag=0;
		int u=fir,v=fir;
		for (int i=1;i<=size;i++)
			if (check(u,v)==0){
				flag=1; break;
			} else {
				u=pre[u]; v=ne[v];
			}
		if (flag==0){
			u=fir; v=fir;
			for (int i=1;i<=size;i++){
				if (u<v){
					swap(A[u],A[v]);
					ans[u]=v; ans[v]=u;
				}
				u=pre[u]; v=ne[v];
			}
			if (size>=100) cerr<<size<<" "<<num<<endl;
			return;
		}
		fir=ne[fir]; num++;
	}
	for (int now=1;now<=size;now++){
		int flag=0;
		int u=fir,v=ne[fir];
		for (int i=1;i<=size;i++)
			if (check(u,v)==0){
				flag=1; break;
			} else {
				u=pre[u]; v=ne[v];
			}
		if (flag==0){
			u=fir; v=ne[fir];
			for (int i=1;i<=size;i++){
				if (u<v){
					swap(A[u],A[v]);
					ans[u]=v; ans[v]=u;
				}
				u=pre[u]; v=ne[v];
			}
			if (size>=100) cerr<<size<<" "<<num<<endl;
			return;
		}
		fir=ne[fir]; num++;
	}
}
void solve(){
	scanf("%d%d%d",&K,&n,&m);
	cerr<<K<<" "<<n<<" "<<m<<endl;
	for (int i=1;i<=n;i++) scanf("%d",&ne[i]),pre[ne[i]]=i,A[i]=ne[i];
	for (int i=1;i<=n;i++) ans[i]=i;
	memset(pd,0x00,sizeof pd);
	for (int i=1;i<=n;i++)
		if (pd[i]==0) getans(i);
	int num=0;
	for (int i=1;i<=n;i++) if (ans[i]<i) num++;
	for (int i=1;i<=n;i++) if (A[i]<i) num++;
	printf("%d\n",num);
	for (int i=1;i<=n;i++) if (ans[i]<i) printf("%d %d 1\n",ans[i],i);
	for (int i=1;i<=n;i++) if (A[i]<i) printf("%d %d 2\n",A[i],i);
}
int main(){
	freopen("sort4.in","r",stdin);
	freopen("sort4.out","w",stdout);
	int t; scanf("%d",&t);
	for (;t;t--) solve();
	return 0;
}
