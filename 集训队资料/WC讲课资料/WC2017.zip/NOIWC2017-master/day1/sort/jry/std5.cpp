#include<iostream>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
int n,K,m,A[110][11000],pd[11000],sign,s[2][11000],where[110][11000],ne[110][11000],pre[110][11000];
int a[110][11000],b[2][11000],x[110][11000];
vector<int>cir[110][11000],way;
queue<int>Q;
int dfs(int K,int *A){
	if (pd[K]) return 0;
	way.push_back(K);
	pd[K]=1; return dfs(A[K],A)+1;
}
int rev(int k1,int k2,int k3){
	if (k2>k3) swap(k2,k3);
	return A[k1][k2]>A[k1][k3];
}
void add(int k1,int k2,int k3){
//	cerr<<"add "<<k1<<" "<<k2<<" "<<k3<<endl; 
	s[k3][k1]=k2; s[k3][k2]=k1;
	if (pd[k1]==0){
		pd[k1]=sign; Q.push(k1);
	}
	if (pd[k2]==0){
		pd[k2]=sign; Q.push(k2);
	}
}
void stand(int k1,int k2,int t){
	if (cir[k1][k2].size()==1) return;
	if (cir[k1][k2].size()==2){
		add(cir[k1][k2][0],cir[k1][k2][1],t^1); 
		return;
	}
	vector<int>a=cir[k1][k2]; 
	for (int i=0;i<3;i++) if (a[i]==k2) swap(a[0],a[i]);
	add(a[1],a[2],t);
	if (t==0) add(ne[k1][k2],k2,t^1); else 
	add(pre[k1][k2],k2,t^1);
}
void change1(int k1,int u,int v){
	if (cir[k1][u].size()==2) return;
	vector<int>a=cir[k1][u];
	if (v!=ne[k1][u]) swap(u,v);
	for (int i=0;i<3;i++) if (a[i]==u) swap(a[0],a[i]);
	for (int i=1;i<3;i++) if (a[i]==v) swap(a[1],a[i]);
	add(a[0],a[2],1);
}
void change2(int k1,int u,int v){
	if (cir[k1][u].size()==2) return;
	vector<int>a=cir[k1][u];
	if (v!=ne[k1][u]) swap(u,v);
	for (int i=0;i<3;i++) if (a[i]==u) swap(a[0],a[i]);
	for (int i=1;i<3;i++) if (a[i]==v) swap(a[1],a[i]);
	add(pre[k1][a[2]],a[2],0);
}
int get(){
//	cerr<<"begin"<<endl;
	while (!Q.empty()){
		int k=Q.front(); Q.pop();
		int u,v,t;// cerr<<k<<endl;
		if (s[0][k]!=k){
			u=k; v=s[0][k]; t=0;
		} else {
			u=k; v=s[1][k]; t=1;
		}
		for (int now=1;now<=K;now++){
			way=cir[now][k]; if (way.size()==1) continue;
		//	cerr<<k<<" "<<way.size()<<endl;
			if (where[now][u]!=where[now][v]){
				stand(now,u,t);
				stand(now,v,t);
			} else if (t==0) change1(now,u,v);
			else change2(now,u,v);
		}
	}
//cerr<<"end "<<endl;
//	exit(0);
	return 1;
}
int c[110000];
int test(){
	int len=0;
	for (int i=1;i<=n;i++)
		if (pd[i]==sign) c[++len]=i;
	for (int i=1;i<=len;i++){
		int k1=c[i],k2=s[0][k1];
		if (s[0][k2]!=k1) return 0;
		k2=s[1][k1];
		if (s[1][k2]!=k1) return 0;
	}
	for (int i=1;i<=K;i++)
		for (int j=1;j<=len;j++) x[i][c[j]]=A[i][c[j]];
	for (int i=0;i<2;i++)
		for (int j=1;j<=len;j++)
			if (s[i][c[j]]<c[j]){
				int u=s[i][c[j]],v=c[j];
				for (int k=1;k<=K;k++)
					if (x[k][u]>x[k][v]) swap(x[k][u],x[k][v]);
			}
//	for (int j=1;j<=len;j++) cerr<<c[j]<<" "; cerr<<endl;
//	for (int i=1;i<=K;i++){
//		for (int j=1;j<=len;j++) cerr<<x[i][c[j]]<<" "; cerr<<endl;}
	for (int i=1;i<=K;i++)
		for (int j=1;j<=len;j++) if (x[i][c[j]]!=c[j]) return 0;
	return 1;
}
int fir=0;
void solve(){
	scanf("%d%d%d",&K,&n,&m);
	for (int i=1;i<=K;i++)	
		for (int j=1;j<=n;j++){
			scanf("%d",&A[i][j]),cir[i][j].clear();
			ne[i][j]=A[i][j]; pre[i][A[i][j]]=j;
		}
//	fir++;
//	if(fir==1) return;
	int totnum=0;
	for (int i=1;i<=K;i++){
		memset(pd,0x00,sizeof pd);
		for (int j=1;j<=n;j++)
			if (pd[j]==0){
				way.clear(); dfs(j,A[i]); sign++;
				sort(way.begin(),way.end());
				if (way.size()==3) totnum++;
				for (int k=0;k<way.size();k++){
					cir[i][way[k]]=way;
					where[i][way[k]]=sign;
				}
			}
	}
	cerr<<totnum<<endl;
//	cerr<<"asd"<<endl;
	for (int i=1;i<=n;i++) s[0][i]=s[1][i]=i;
	memset(pd,0x00,sizeof pd);
	for (int i=1;i<=n;i++)
		if (pd[i]==0){
			sign++; //cerr<<i<<endl;
			memcpy(a,pd,sizeof pd);
			memcpy(b,s,sizeof s);
			for (int j=1;j<=K;j++)
				if (cir[j][i].size()==2){
				//	cerr<<j<<endl;
					while (!Q.empty()) Q.pop();
					add(cir[j][i][0],cir[j][i][1],0);
					if (get()&&test()) break;
					memcpy(pd,a,sizeof pd);
					memcpy(s,b,sizeof s);
					while (!Q.empty()) Q.pop();
					add(cir[j][i][1],cir[j][i][0],1);
					if (get()&&test()) break;
					memcpy(pd,a,sizeof pd);
					memcpy(s,b,sizeof s);
					cerr<<"false"<<endl; exit(0);
				} else if (cir[j][i].size()==3){
					if (rev(j,cir[j][i][0],cir[j][i][1])){
						while (!Q.empty()) Q.pop();
						add(cir[j][i][0],cir[j][i][1],0);
						if (get()&&test()) break;
						memcpy(pd,a,sizeof pd);
						memcpy(s,b,sizeof s);
					}
					if (rev(j,cir[j][i][0],cir[j][i][2])){
						while (!Q.empty()) Q.pop();
						add(cir[j][i][0],cir[j][i][2],0);
						if (get()&&test()) break;
						memcpy(pd,a,sizeof pd);
						memcpy(s,b,sizeof s);
					}
					if (rev(j,cir[j][i][1],cir[j][i][2])){
						while (!Q.empty()) Q.pop();
						add(cir[j][i][1],cir[j][i][2],0);
						if (get()&&test()) break;
						memcpy(pd,a,sizeof pd);
						memcpy(s,b,sizeof s);
					}
					cerr<<"false"<<endl; exit(0);
				}
//	exit(0); 
		} 
//	for (int i=1;i<=n;i++) cerr<<pd[i]<<" "; cerr<<endl;
	int num=0;
	for (int i=1;i<=n;i++){
		if (s[0][i]<i) num++;
		if (s[1][i]<i) num++;
	}
	printf("%d\n",num);
	for (int i=0;i<2;i++)
		for (int j=1;j<=n;j++)
			if (s[i][j]<j) printf("%d %d %d\n",s[i][j],j,i+1);
	return;
}
int main(){
	freopen("sort5.in","r",stdin);
	freopen("sort5.out","w",stdout);
	int t; scanf("%d",&t); t=1;
	for (;t;t--){
		cerr<<t<<endl; solve();
	}
	return 0;
}
