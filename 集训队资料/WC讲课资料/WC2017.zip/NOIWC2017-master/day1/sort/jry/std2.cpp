#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int pd[100],len,a[1000][15],A[110][11],aim[15],K,n,m,flag,use[100],w[1000];
void get(int k1,int k2){
	if (k1>k2){
		len++; memcpy(a[len],aim,sizeof aim);
		return;
	}
	if (aim[k1]) get(k1+1,k2);
	else for (int i=k1+1;i<=k2;i++)
		if (aim[i]==0){
			aim[i]=k1; aim[k1]=i;
			get(k1+1,k2);
			aim[i]=0; aim[k1]=0;
		}
}
void change(int *A,int *B){
	for (int i=1;i<=n;i++)
		if (B[i]<i&&A[B[i]]>A[i]) swap(A[B[i]],A[i]);
}
int change1(int *A,int *B){
	int num=0;
	for (int i=1;i<=n;i++)
		if (B[i]<i&&A[B[i]]>A[i]) num++;
	return num;
}
int ans[11];
int check(int d){
	for (int i=1;i<=n;i++) ans[i]=i;
	for (int i=1;i<=K;i++)
		for (int j=1;j<=n;j++)
			if (A[i][j]!=j){ 
				if ((ans[j]!=j&&ans[j]!=A[i][j])||A[i][A[i][j]]!=j) return 0;
				ans[j]=A[i][j];
			}
	int num=0;
	for (int now=1;now<d;now++){
		for (int i=1;i<=n;i++) if (a[use[now]][i]<i) num++;
	}
	for (int i=1;i<=n;i++) if (ans[i]<i) num++;
	printf("%d\n",num);
	for (int now=1;now<d;now++){
		for (int i=1;i<=n;i++) if (a[use[now]][i]<i){
			printf("%d %d %d\n",a[use[now]][i],i,now);
		}
	}
	for (int i=1;i<=n;i++) if (ans[i]<i) printf("%d %d %d\n",ans[i],i,d);
	return 1;
}
int compare(int k1,int k2){
	return w[k1]>w[k2];
}
void findans(int k1){
	if (check(k1)){
		flag=1; cerr<<k1<<endl;
	//	print(K);
		return;
	}
	if (k1>=m) return;
	int pre[110][11],b[1000];
	memcpy(pre,A,sizeof A);
	for (int i=1;i<=len;i++){
		w[i]=0; b[i]=i;
		for (int j=1;j<=K;j++) w[i]+=change1(A[j],a[i]);
	}
	sort(b+1,b+len+1,compare);
	for (int i=1;i<=len&&flag==0;i++){
		for (int j=1;j<=K;j++) change(A[j],a[b[i]]);
		use[k1]=b[i]; findans(k1+1);
		memcpy(A,pre,sizeof pre);
	}
}
int main(){
	freopen("sort2.in","r",stdin);
	freopen("sort21.out","w",stdout);
	int t; scanf("%d",&t); t=10;
	for (;t;t--){
		scanf("%d%d%d",&K,&n,&m); len=0; flag=0;
		for (int i=1;i<=K;i++)
			for (int j=1;j<=n;j++) scanf("%d",&A[i][j]);
		get(1,n+(n&1));// cout<<len<<endl;
	//	for (int i=1;i<=len;i++){
	//		for (int j=1;j<=n;j++) cout<<a[i][j]<<" "; cout<<endl;}
		findans(1); 
	}
	return 0;
}
