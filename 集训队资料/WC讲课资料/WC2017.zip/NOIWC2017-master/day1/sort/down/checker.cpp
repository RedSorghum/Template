#include<iostream>
#include<cmath>
#include<cstring>
#include <fstream>
#include<cstdio>
#include<algorithm>
#include<cassert>
#include<vector>
using namespace std;
FILE *in,*out;
int pd[110000],n,m,K,sign,tot,a[110000],ans,flag,c[1100];
struct atom{
	int u,v,t;
	void scan(){
		if (fscanf(out,"%d%d%d",&u,&v,&t)!=3) flag=1;
		if (u>v) swap(u,v);
		ans=max(ans,t);
	}
	void change(){
		if (a[u]>a[v]) swap(a[u],a[v]);
	}
}A[1100000],B[1100000];
int compare(atom k1,atom k2){
	return k1.t<k2.t;
}
int po;
void readrem(){
	for (;K;K--){
		for (int i=1;i<=n;i++) assert(fscanf(in,"%d",&a[i])==1);
	}
}
void check(){
	flag=0;
	assert(fscanf(in,"%d%d%d",&K,&n,&m)==3);
	int num=0;
	if (fscanf(out,"%d",&tot)!=1) flag=1; ans=0;
	if (tot>1000000||tot<0){
		printf("The number of the comparators is invalid!\n");
		exit(0);
	}
	for (int i=1;i<=tot;i++){
		B[i].scan(); num=max(num,B[i].t);
	}
	if (flag==1){
		printf("Unexpected EOF\n"); readrem();
		return;
	}
	for (int i=1;i<=tot;i++)
		if (B[i].t<=0||B[i].t>150){
			printf("The running time of the comparator should be in [1, 150]\n");
			readrem();
			return;
		}
	if (num>m){
		printf("Invalid! m=%d but M=%d\n",m,num);
		readrem(); return;
	}
	for (int i=1;i<=tot;i++)
		if (B[i].u<=0||B[i].u>n||B[i].v<=0||B[i].v>n||B[i].u>=B[i].v){
			printf("Invalid sorting network!\n"); 
			readrem(); return;
		}
	for (int i=1;i<=m;i++) c[i]=0;
	for (int i=1;i<=tot;i++) c[B[i].t]++;
	for (int i=1;i<=m;i++) c[i]+=c[i-1];
	for (int i=1;i<=tot;i++){
		A[c[B[i].t]]=B[i]; c[B[i].t]--;
	}
	int pre=0;
	for (int i=1;i<=tot;i++){
		if (A[i].t!=pre){
			pre=A[i].t; sign++;
		}
		if (pd[A[i].u]==sign||pd[A[i].v]==sign){
			printf("Invalid sorting network!\n");
			readrem(); return;
		}
		pd[A[i].u]=sign; pd[A[i].v]=sign;
	}
	for (;K;K--){
		for (int i=1;i<=n;i++) assert(fscanf(in,"%d",&a[i])==1);
		for (int i=1;i<=tot;i++) A[i].change();
		for (int i=1;i<n;i++)
			if (a[i]>a[i+1]) flag=1;
	}
	if (flag==1){
		printf("The answer is incorrect\n"); return;
	}
	po++;
	printf("Correct! m=%d and M=%d\n",m,num);
}
int main(int argc,char **argv){
	in=fopen(argv[1],"r");
	out=fopen(argv[2],"r");
//	freopen("data.out","w",stdout);
//	freopen("score.txt","w",stdout);
	int t; fscanf(in,"%d",&t);
	for (int i=1;i<=t;i++){
		printf("Case #%d: ",i);
		//cerr<<t<<endl; 
		check();
	}
	printf("Total points: %d\n",po);
	//cerr<<"correct"<<endl;
}
