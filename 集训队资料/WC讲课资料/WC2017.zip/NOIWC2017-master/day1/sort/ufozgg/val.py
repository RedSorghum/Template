import json
import re

inf = 1e100

class InputException(Exception):
	def __init__(self, value = ''):
		self.value = value
	def __str__(self):
		return '[E]At line %d : %s' % (line, repr(self.value))
		
def get_strs(f, num = None, split = ' '):
	global line
	line += 1
	items = f.readline().strip('\n').split(split)
	if num != None and len(items) != num:
		raise InputException('Must contain %d items, but %d get.%s' % (
			num,
			len(items),
			' May contain extra spaces at the end of the line.' if len(items) > num else ''
		))
	return items

def get_ints(f, num = None, split = ' '):
	items = get_strs(f, num, split)
	try:
		return list(map(int, items))
	except Exception as e:
		raise InputException(e)
		
def get_eof(f):
	global line
	line += 1
	extra = f.readline()
	if extra:
		raise InputException('Must get EOF but "%s" get.' % extra)
		
def check_in(item, in_set, name = None):
	if item not in in_set:
		raise InputException('Variable%s must in %s, but %s get.' % (' "' + name + '"' if name else '', repr(in_set), repr(item)))
		
def check_re(item, r, name = None):
	if not r.match(item):
		raise InputException('Variable%s must match "%s", but %s get.' % (' "' + name + '"' if name else '', r.pattern, repr(item)))
		
def check_true(result, info = None):
	if not result:
		raise InputException(info if info else 'Expression must be True but False get.')

def check(f, args = None):
	first_self_loop = True
	first_repeat_edge = True
	try:
		tt = get_ints(f,1)
		t = tt[0]
		print('t = %d' % t)
		for i in range(t):
			k, n, m = get_ints(f,3)
			check_in(k, range(1, 10001), 'k')
			check_in(n, range(1, 100001), 'n')
			check_in(m, range(1, 10001), 'm')
			for j in range(k):
				c = get_ints(f,n)
				c.sort()
				for s in range(n):
					if c[s] != s + 1:
						print('Wrong in i = %d j = %d num = %d'%(i+1,j+1,s+1))
		get_eof(f)
		print('Check succeeded.')
	except Exception as e:
		print(e)
		print('Check failed.')

if __name__ == '__main__':
	conf = json.loads(open('../prob.json', 'rb').read().decode('utf-8'))
	for i in range(conf['test cases']):
		with open('../down/%s%d.in' % (conf['name'], i + 1), 'r') as f:
			line = 0
			print('Checking down %d' % (i + 1))
			check(f)
	for i in range(conf['test cases']):
		with open('../data/%s%d.in' % (conf['name'], i + 1), 'r') as f:
			line = 0
			print('Checking data %d' % (i + 1))
			check(f)
