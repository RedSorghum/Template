fpc -O2 $1.pas && mv $1 $1.exe
