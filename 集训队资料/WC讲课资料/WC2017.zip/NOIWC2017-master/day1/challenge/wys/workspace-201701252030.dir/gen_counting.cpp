#include <stdio.h>

#include "../header.h"

int seed;

inline int get_rand() {
    return seed = seed * 16807LL % 2147483647;
}

inline int clamp(int x, int l, int r) {
    return x < l ? l : x > r ? r : x;
}

const int DIM = 5;

int main(int argc, char **argv) {
    if (argc != 1 + 3) {  // exe <n> <q> <seed>
        return 1;
    }
    
    int n, q;
    
    if (sscanf(argv[1], "%d", &n) != 1 || n < 1) {
        return 1;
    }
    
    if (sscanf(argv[2], "%d", &q) != 1 || q < 1) {
        return 1;
    }
    
    if (sscanf(argv[3], "%d", &seed) != 1 || seed < 0 || seed >= 2147483647) {
        return 1;
    }
    
    puts("3");
    printf("%d %d\n", n, q);
    
    for (int i = 0; i < n; i++) {
        int x[DIM];
        for (int j = 0; j < DIM; j++) {
            x[j] = get_rand() % n;
        }
        for (int j = 0; j < DIM; j++) {
            printf("%d%c", x[j], " \n"[j == DIM - 1]);
        }
    }
    
    for (int i = 0; i < q; i++) {
        int x[DIM];
        
        int tmp = get_rand() % 1000;
        int t;
        if (tmp < 65) {
            t = 0;
        } else if (tmp < 130) {
            t = n / 4;
        } else if (tmp < 500) {
            t = n / 2;
        } else if (tmp < 850) {
            t = n / 1.5;
        } else {
            t = n / 1.3;
        }
        
        for (int j = 0; j < DIM; j++) {
            x[j] = clamp(get_rand() % (n - t) + t, 0, n - 1);
        }
        for (int j = 0; j < DIM; j++) {
            printf("%d%c", x[j], " \n"[j == DIM - 1]);
        }
    }
}
