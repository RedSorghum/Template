g++ -m32 -O2 $1.cpp -o $1.exe -Wno-unused-result
