#include <stdio.h>
#include <string.h>
#include <algorithm>

typedef unsigned int u32;
typedef unsigned long long u64;

inline u32 next_integer(u32 x) {
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

bool output_arr(void *a, u32 size) {
    if (size % 4) {
        return puts("-1"), 0;
    }
    
    u32 blocks = size / 4;
    u32 *A = (u32 *)a;
    u32 ret = size;
    u32 x = 23333333;
    for (u32 i = 0; i < blocks; i++) {
        ret = ret ^ (A[i] + x);
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    
    return printf("%u\n", ret), 1;
}

// ===== header ======


namespace Sorting {
    void main() {
        int n;
        u32 seed;
        scanf("%d%u", &n, &seed);
        
        u32 *a = new u32[n];
        for (int i = 0; i < n; i++) {
            seed = next_integer(seed);
            a[i] = seed;
        }
        
        // sort(a, n);
        
        output_arr(a, n * sizeof(u32));
    }
}


namespace MST {
    void main() {
        int n;
        scanf("%d", &n);
        
        int *x = new int[n];
        int *y = new int[n];
        for (int i = 0; i < n; i++) {
            scanf("%d%d", x + i, y + i);
        }
        
        u64 *edge_len = new u64[n - 1];
        
        // get_MST(edge_len, x, y, n);
        
        output_arr(edge_len, (n - 1) * sizeof(u64));
    }
}


namespace Counting {
    struct Point {
        int x[5];
    };
    
    inline void read_point(Point &a) {
        scanf("%d%d%d%d%d", a.x, a.x + 1, a.x + 2, a.x + 3, a.x + 4);
    }
    
    inline bool operator <= (const Point &a, const Point &b) {
        return a.x[0] <= b.x[0] & a.x[1] <= b.x[1] & a.x[2] <= b.x[2] & a.x[3] <= b.x[3] & a.x[4] <= b.x[4];
    }
    
    struct Point4 {
        int x[4];
    };
    
    inline bool operator <= (const Point4 &a, const Point4 &b) {
        return a.x[0] <= b.x[0] & a.x[1] <= b.x[1] & a.x[2] <= b.x[2] & a.x[3] <= b.x[3];
    }
    
    int cmp_id;
    
    bool cmp(const Point &a, const Point &b) {
        return a.x[cmp_id] < b.x[cmp_id];
    }
    
    void solve(int n, int q, Point *a, Point *queries, u32 *anss) {
        Point4 *b[5];
        int *bounds[5];
        for (int i = 0; i < 5; i++) {
            b[i] = new Point4[n];
            cmp_id = i;
            std::sort(a, a + n, cmp);
            for (int j = 0; j < n; j++) {
                Point4 tmp4;
                for (int k = 0; k < 5; k++) {
                    if (k != i) tmp4.x[k - (k > i)] = a[j].x[k];
                }
                b[i][j] = tmp4;
            }
            bounds[i] = new int[n];
            int p = 0;
            for (int j = 0; j < n; j++) {
                while (p < n && a[p].x[i] == j) ++p;
                bounds[i][j] = p;
            }
        }
        for (int i = 0; i < q; i++) {
            u32 ans = 0;
            Point tmp5 = queries[i];
            int id = 0, bound = bounds[0][tmp5.x[0]];
            for (int j = 1; j < 5; j++) {
                int tmp_bound = bounds[j][tmp5.x[j]];
                if (tmp_bound < bound) {
                    bound = tmp_bound;
                    id = j;
                }
            }
            Point4 tmp4;
            for (int k = 0; k < 5; k++) {
                if (k != id) tmp4.x[k - (k > id)] = tmp5.x[k];
            }
            Point4 *points = b[id];
            for (int j = 0; j < bound; j++) {
                ans += points[j] <= tmp4;
            }
            anss[i] = ans;
        }
    }
    
    void main() {
        int n, q;
        scanf("%d%d", &n, &q);
        
        Point *a = new Point[n];
        for (int i = 0; i < n; i++) read_point(a[i]);
        
        Point *queries = new Point[q];
        for (int i = 0; i < q; i++) read_point(queries[i]);
        
        u32 *anss = new u32[q];
        solve(n, q, a, queries, anss);
        
        output_arr(anss, q * sizeof(u32));
    }
}


namespace Parentheses {
    u32 solve(int n, char *s) {
        u32 *dp_now = new u32[n + 1];
        u32 *dp_pre = new u32[n + 1];
        memset(dp_now, 0, n * sizeof(u32));
        dp_now[0] = 1;
        
        for (int i = 0; i < n; i++) {
            u32 *tmp = dp_now;
            dp_now = dp_pre, dp_pre = tmp;
            
            int m = std::min(i + 1, n - i);
            
            if (s[i] == '(') {
                dp_now[0] = 0;
                for (int j = 1; j <= m; j++) {
                    dp_now[j] = dp_pre[j - 1];
                }
            } else if (s[i] == ')') {
                for (int j = 0; j < m; j++) {
                    dp_now[j] = dp_pre[j + 1];
                }
                dp_now[m] = 0;
            } else {
                dp_now[0] = dp_pre[1];
                for (int j = 1; j < m; j++) {
                    dp_now[j] = dp_pre[j - 1] + dp_pre[j + 1];
                }
                dp_now[m] = dp_pre[m - 1];
            }
        }
        
        return dp_now[0];
    }
    
    void main() {
        int n;
        scanf("%d", &n);
        
        char *s = new char[n + 1];
        scanf("%s", s);
        
        u32 ans;
        ans = solve(n, s);
        
        printf("%u\n", ans);
    }
}


int main() {
    int task_id;
    scanf("%d", &task_id);
    
    switch (task_id) {
        case 1:
            Sorting::main();
            break;
        case 2:
            MST::main();
            break;
        case 3:
            Counting::main();
            break;
        case 4:
            Parentheses::main();
            break;
    }
    
    return 0;
}

