#include <stdio.h>
#include <string.h>
#include <algorithm>

typedef unsigned int u32;
typedef unsigned long long u64;

inline u32 next_integer(u32 x) {
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

bool output_arr(void *a, u32 size) {
    if (size % 4) {
        return puts("-1"), 0;
    }
    
    u32 blocks = size / 4;
    u32 *A = (u32 *)a;
    u32 ret = size;
    u32 x = 23333333;
    for (u32 i = 0; i < blocks; i++) {
        ret = ret ^ (A[i] + x);
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    
    return printf("%u\n", ret), 1;
}

// ===== header ======


namespace Sorting {
    void main() {
        int n;
        u32 seed;
        scanf("%d%u", &n, &seed);
        
        u32 *a = new u32[n];
        for (int i = 0; i < n; i++) {
            seed = next_integer(seed);
            a[i] = seed;
        }
        
        std::sort(a, a + n);
        
        output_arr(a, n * sizeof(u32));
    }
}


namespace MST {
    
    int *fa;
    
    inline int get_fa(int x) {
        return fa[x] ? fa[x] = get_fa(fa[x]) : x;
    }
    
    inline bool merge(int x, int y) {
        x = get_fa(x), y = get_fa(y);
        if (x == y) return false;
        return fa[x] = y, true;
    }
    
    struct edge {
        int x, y;
        u64 len;
    };
    
    inline u64 sqr(int x) {
        return x * (long long)x;
    }
    
    inline bool cmp_edge(const edge &a, const edge &b) {
        return a.len < b.len;
    }
    
    void get_MST(u64 *edge_len, int *x, int *y, int n) {
        fa = new int[n + 1];
        memset(fa, 0, (n + 1) * sizeof(int));
        edge *edges = new edge[n * (n - 1) / 2];
        int cnt = 0;
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                u64 len = sqr(x[i] - x[j]) + sqr(y[i] - y[j]);
                edges[cnt++] = (edge){i + 1, j + 1, len};
            }
        }
        std::sort(edges, edges + cnt, cmp_edge);
        int n_merge = 0;
        for (int i = 0; i < cnt; i++) {
            const edge &e = edges[i];
            if (merge(e.x, e.y)) {
                edge_len[n_merge] = e.len;
                if (++n_merge == n - 1) break;
            }
        }
    }
    
    void main() {
        int n;
        scanf("%d", &n);
        
        int *x = new int[n];
        int *y = new int[n];
        for (int i = 0; i < n; i++) {
            scanf("%d%d", x + i, y + i);
        }
        
        u64 *edge_len = new u64[n - 1];
        
        get_MST(edge_len, x, y, n);
        
        output_arr(edge_len, (n - 1) * sizeof(u64));
    }
}


namespace Counting {
    struct Point {
        int x[5];
    };
    
    inline void read_point(Point &a) {
        scanf("%d%d%d%d%d", a.x, a.x + 1, a.x + 2, a.x + 3, a.x + 4);
    }
    
    inline bool operator <= (const Point &a, const Point &b) {
        return a.x[0] <= b.x[0] && a.x[1] <= b.x[1] && a.x[2] <= b.x[2] && a.x[3] <= b.x[3] && a.x[4] <= b.x[4];
    }
    
    void solve(int n, int q, Point *a, Point *queries, u32 *anss) {
        for (int i = 0; i < q; i++) {
            u32 ans = 0;
            for (int j = 0; j < n; j++) {
                ans += a[j] <= queries[i];
            }
            anss[i] = ans;
        }
    }
    
    void main() {
        int n, q;
        scanf("%d%d", &n, &q);
        
        Point *a = new Point[n];
        for (int i = 0; i < n; i++) read_point(a[i]);
        
        Point *queries = new Point[q];
        for (int i = 0; i < q; i++) read_point(queries[i]);
        
        u32 *anss = new u32[q];
        solve(n, q, a, queries, anss);
        
        output_arr(anss, q * sizeof(u32));
    }
}


namespace Parentheses {
    u32 solve(int n, char *s) {
        u32 *dp_now = new u32[n + 1];
        u32 *dp_pre = new u32[n + 1];
        memset(dp_now, 0, n * sizeof(u32));
        dp_now[0] = 1;
        
        for (int i = 0; i < n; i++) {
            u32 *tmp = dp_now;
            dp_now = dp_pre, dp_pre = tmp;
            
            if (s[i] == '(') {
                dp_now[0] = 0;
                for (int j = 1; j <= n; j++) {
                    dp_now[j] = dp_pre[j - 1];
                }
            } else if (s[i] == ')') {
                for (int j = 0; j < n; j++) {
                    dp_now[j] = dp_pre[j + 1];
                }
                dp_now[n] = 0;
            } else {
                dp_now[0] = dp_pre[1];
                for (int j = 1; j < n; j++) {
                    dp_now[j] = dp_pre[j - 1] + dp_pre[j + 1];
                }
                dp_now[n] = dp_pre[n - 1];
            }
        }
        
        return dp_now[0];
    }
    
    void main() {
        int n;
        scanf("%d", &n);
        
        char *s = new char[n + 1];
        scanf("%s", s);
        
        u32 ans;
        ans = solve(n, s);
        
        printf("%u\n", ans);
    }
}


int main() {
    int task_id;
    scanf("%d", &task_id);
    
    switch (task_id) {
        case 1:
            Sorting::main();
            break;
        case 2:
            MST::main();
            break;
        case 3:
            Counting::main();
            break;
        case 4:
            Parentheses::main();
            break;
    }
    
    return 0;
}
