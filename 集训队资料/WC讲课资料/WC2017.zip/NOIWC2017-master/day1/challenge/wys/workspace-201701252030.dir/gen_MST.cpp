#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "../header.h"

bool gen(int argc, char **argv) {
    // xxx.exe n seed
    
    int n;
    u32 seed;
    
    if (argc != 1 + 2) {
        return false;
    }
    
    if (sscanf(argv[1], "%d", &n) != 1 || n < 1) {
        return false;
    }
    
    if (sscanf(argv[2], "%u", &seed) != 1) {
        return false;
    }
    
    puts("2");
    printf("%d\n", n);
    
    for (int i = 0; i < n; i++) {
        u32 t1 = next_integer(seed);
        u32 t2 = next_integer(t1);
        seed = t2;
        
        t1 &= (1 << 30) - 1;
        t2 &= (1 << 30) - 1;
        
        const double center = 1 << 29;
        double dist = (t1 - center) * (t1 - center) + (t2 - center) * (t2 - center);
        dist = sqrt(dist);
        if (dist > center * 0.07 && dist < center * 0.75 && next_integer(seed) % 1000 < 998) {
            --i;continue;
        }
        
        printf("%d %d\n", (int)t1, (int)t2);
    }
    
    return true;
}

int main(int argc, char **argv) {
    if (!gen(argc, argv)) {
        return 1;
    }
}
