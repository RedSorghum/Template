bash -c "time ./$1.exe < $2.in > output.txt"
diff -s -b $2.ans output.txt | head -n 1
