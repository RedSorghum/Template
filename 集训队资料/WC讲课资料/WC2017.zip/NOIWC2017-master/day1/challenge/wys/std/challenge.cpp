#include <stdio.h>
#include <string.h>
#include <algorithm>

typedef unsigned int u32;
typedef unsigned long long u64;

inline u32 next_integer(u32 x) {
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

bool output_arr(void *a, u32 size) {
    if (size % 4) {
        return puts("-1"), 0;
    }
    
    u32 blocks = size / 4;
    u32 *A = (u32 *)a;
    u32 ret = size;
    u32 x = 23333333;
    for (u32 i = 0; i < blocks; i++) {
        ret = ret ^ (A[i] + x);
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    
    return printf("%u\n", ret), 1;
}

// ===== header ======


namespace Sorting {
    void init_data(u32 *a, int n, u32 seed) {
        for (int i = 0; i < n; i++) {
            seed = next_integer(seed);
            a[i] = seed;
        }
    }
    
    u32 * sort(u32 *a, int n) {
        const int S = 8;
        u32 *b = new u32[n];
        static u32 cnt[1 << S];
        for (int i = 0; i < 32; i += S) {
            memset(cnt, 0, sizeof(cnt));
            if (i + S >= 32) {
                for (int j = 0; j < n; j++) ++cnt[a[j] >> i];
                for (int j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
                for (int j = n - 1; j >= 0; j--) b[--cnt[a[j] >> i]] = a[j];
                u32 *tmp = a;
                a = b, b = tmp;
                continue;
            }
            u32 t = (1 << S) - 1;
            for (int j = 0; j < n; j++) ++cnt[(a[j] >> i) & t];
            for (int j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
            for (int j = n - 1; j >= 0; j--) b[--cnt[(a[j] >> i) & t]] = a[j];
            u32 *tmp = a;
            a = b, b = tmp;
        }
        return a;
    }
    
    void main() {
        int n;
        u32 seed;
        scanf("%d%u", &n, &seed);
        
        u32 *a = new u32[n];
        init_data(a, n, seed);
        
        a = sort(a, n);
        
        output_arr(a, n * sizeof(u32));
    }
}


namespace Game {
    
    inline void add_bit(u32 *a, int pos, int x) {
        a[pos >> 5] += x << (pos & 31);
    }
    
    int cnt_table[1 << 16];
    
    void count_pre() {
        cnt_table[0] = 0;
        for (int i = 1; i < 1 << 16; i++) {
            cnt_table[i] = cnt_table[i >> 1] + (i & 1);
        }
    }
    
    inline int count(u32 x) {
        return cnt_table[x >> 16] + cnt_table[x & 65535u];
    }
    
    void solve(int n, int q, char *s1, char *s2, int *q_x, int *q_y, int *q_len, u32 *anss) {
        int *a = new int[n];
        int *b = new int[n];
        
        for (int i = 0; i < n; i++) {
            a[i] = s1[i] - '0';
            b[i] = s2[i] - '0';
        }
        
        for (int i = 0; i < n; i++) {
            b[i] = (b[i] - 1 + 3) % 3;
        }
        
        u32 *bs_a[32], *bs_b[32];
        
        for (int i = 0; i < 32; i++) {
            bs_a[i] = new u32[n * 3 / 32 + 2];
            bs_b[i] = new u32[n * 3 / 32 + 2];
            memset(bs_a[i], 0, (n * 3 / 32 + 2) * sizeof(u32));
            memset(bs_b[i], 0, (n * 3 / 32 + 2) * sizeof(u32));
            for (int j = i; j < n * 3; j++) {
                add_bit(bs_a[i], j - i, a[j / 3] == j % 3);
                add_bit(bs_b[i], j - i, b[j / 3] == j % 3);
            }
        }
        
        count_pre();
        
        for (int i = 0; i < q; i++) {
            int x = 3 * q_x[i], y = 3 * q_y[i];
            int len = 3 * q_len[i];
            u32 ans = 0;
            
            u32 *aa = bs_a[x & 31] + (x >> 5);
            u32 *bb = bs_b[y & 31] + (y >> 5);
            
            int l1 = len >> 5;
            
            for (int j = 0; j < l1; j++) {
                ans += count(aa[j] & bb[j]);
            }
            
            ans += count(aa[l1] & bb[l1] & ((1u << (len & 31)) - 1));
            
            anss[i] = ans;
        }
    }
    
    void main() {
        int n, q;
        scanf("%d%d", &n, &q);
        
        char *s1 = new char[n + 1];
        char *s2 = new char[n + 1];
        scanf("%s%s", s1, s2);
        
        u32 *anss = new u32[q];
        int *q_x = new int[q];
        int *q_y = new int[q];
        int *q_len = new int[q];
        
        for (int i = 0; i < q; i++) {
            scanf("%d%d%d", q_x + i, q_y + i, q_len + i);
        }
        
        solve(n, q, s1, s2, q_x, q_y, q_len, anss);
        
        output_arr(anss, q * sizeof(u32));
    }
}


namespace Parentheses {
    void add(u32 *a, int m) {
        int j = 0;
        for (; j + 4 <= m; j += 4) {
            u32 s0 = a[j] + a[j + 1];
            u32 s1 = a[j + 1] + a[j + 2];
            u32 s2 = a[j + 2] + a[j + 3];
            u32 s3 = a[j + 3] + a[j + 4];
            a[j] = s0;
            a[j + 1] = s1;
            a[j + 2] = s2;
            a[j + 3] = s3;
        }
        for (; j < m; j++) {
            a[j] += a[j + 1];
        }
    }
    
    u32 solve(int n, char *s) {
        u32 *dp = (new u32[(int)(1.5 * n) + 10]) + (int)(n * 0.5) + 5;
        memset(dp, 0, n * sizeof(u32));
        dp[0] = 1;
        
        for (int i = 0; i < n; i++) {
            int m = std::min(i + 1, n - i - 1) / 2;
            
            if (s[i] == '(') {
                if (i % 2 == 1) {
                    --dp;
                    dp[0] = 0;
                }
            } else if (s[i] == ')') {
                if (i % 2 == 0) {
                    ++dp;
                }
            } else {
                if (i % 2 == 0) {
                    // 0 ~ m: += + 1
                    add(dp, m + 1);
                    dp[m + 1] = 0;
                } else {
                    // 0 ~ m - 1: += +1
                    // -1: = 0
                    u32 tmp0 = dp[0];
                    add(dp, m);
                    dp[m] = 0;
                    dp[-1] = tmp0;
                    --dp;
                }
            }
        }
        
        return dp[0] * (n % 2 == 0);
    }
    
    void main() {
        int n;
        scanf("%d", &n);
        
        char *s = new char[n + 1];
        scanf("%s", s);
        
        u32 ans;
        ans = solve(n, s);
        
        printf("%u\n", ans);
    }
}


int main() {
    freopen("challenge.in", "r", stdin);
    freopen("challenge.out", "w", stdout);
    int task_id;
    scanf("%d", &task_id);
    
    switch (task_id) {
        case 1:
            Sorting::main();
            break;
        case 2:
            Game::main();
            break;
        case 3:
            Parentheses::main();
            break;
    }
    
    return 0;
}
