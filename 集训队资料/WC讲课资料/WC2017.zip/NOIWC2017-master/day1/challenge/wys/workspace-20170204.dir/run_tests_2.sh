# $1 exe, $2 prob name, $3 l, $4 r
let l=$3
let r=$4
echo "Testing $1.exe using $2$l~$2$r.in/ans ..."
for ((i=l;i<=r;i++)) do (
    str_t=`{ time ./$1.exe < $2$i.in > output.txt 2> stderr.txt ; } 2>&1 | head -n 3 | tail -n 2` ;
    # str_t=${str_t/\n/ } ;
    str_d=`diff -s -b $2$i.ans output.txt 2>&1 | head -n 1` ;
    echo "$2 $i : $str_t , $str_d" ;
) done ;

