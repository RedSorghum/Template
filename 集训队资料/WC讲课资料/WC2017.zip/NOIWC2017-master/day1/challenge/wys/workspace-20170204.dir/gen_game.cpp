#include <stdio.h>
#include <algorithm>

int seed;

inline int next_integer(int x) {
    return x * 16807LL % 2147483647;
}

inline int rnd() {
    return seed = next_integer(seed);
}

int main(int argc, char **argv) {
    if (argc != 1 + 3) {  // exe <n> <q> <seed>
        return 1;
    }
    
    int n, q;
    
    if (sscanf(argv[1], "%d", &n) != 1 || n < 1) {
        return 1;
    }
    
    if (sscanf(argv[2], "%d", &q) != 1 || q < 1) {
        return 1;
    }
    
    if (sscanf(argv[3], "%d", &seed) != 1 || seed < 0 || seed >= 2147483647) {
        return 1;
    }
    
    puts("2");
    
    printf("%d %d\n", n, q);
    
    for (int i = 0; i < n; i++) {
        int x = rnd();
        
        int t = x % 999;
        int val = t / 333;
        
        putchar(val + 48);
    }
    putchar('\n');
    
    for (int i = 0; i < n; i++) {
        int x = rnd();
        
        int t = x % 999;
        int val = t / 333;
        
        putchar(val + 48);
    }
    putchar('\n');
    
    for (int i = 0; i < q; i++) {
        int x, y;
        int d = rnd() % (2 * (n - 1) + 1) - (n - 1);
        int maxlen = d < 0 ? n + d : n - d;
        x = rnd() % maxlen;
        if (d < 0) {
            y = x, x -= d;
        } else {
            y = x + d;
        }
        int maxlen2 = n - std::max(x, y);
        int len = rnd() % maxlen2;
        
        printf("%d %d %d\n", x, y, maxlen2);
    }
}
