#include <stdio.h>

int seed;

inline int get_rand() {
    return seed = seed * 16807LL % 2147483647;
}

int main(int argc, char **argv) {
    if (argc != 1 + 3) {  // exe <n> <cnt> <seed>
        return 1;
    }
    
    int n, cnt;
    
    if (sscanf(argv[1], "%d", &n) != 1 || n < 1) {
        return 1;
    }
    
    if (sscanf(argv[2], "%d", &cnt) != 1 || cnt < 0 || cnt > n) {
        return 1;
    }
    
    if (sscanf(argv[3] ,"%d", &seed) != 1 || seed < 0 || seed > 2147483647) {
        return 1;
    }
    
    puts("3");
    
    printf("%d\n", n);
    for (int i = 0; i < n; i++) {
        int t = get_rand() % n;
        if (t < cnt) {
            int t2 = get_rand();
            putchar("()"[(t2 >> 11) & 1]);
        } else {
            putchar('?');
        }
    }
    putchar('\n');
}
