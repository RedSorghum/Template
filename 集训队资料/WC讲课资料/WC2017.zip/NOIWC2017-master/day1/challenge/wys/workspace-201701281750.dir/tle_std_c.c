#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define bool int
#define true 1
#define false 0

typedef unsigned int u32;
typedef unsigned long long u64;

inline u32 next_integer(u32 x) {
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

bool output_arr(void *a, u32 size) {
    if (size % 4) {
        return puts("-1"), 0;
    }
    
    u32 blocks = size / 4;
    u32 *A = (u32 *)a;
    u32 ret = size;
    u32 x = 23333333;
    u32 i;
    for (i = 0; i < blocks; i++) {
        ret = ret ^ (A[i] + x);
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    
    return printf("%u\n", ret), 1;
}

// ===== header ======

u32 * sort(u32 *a, int n) {
    const int S = 8;
    u32 *b = malloc(n * sizeof(u32));
    static u32 cnt[256];
    int i, j;
    for (i = 0; i < 32; i += S) {
        memset(cnt, 0, sizeof(cnt));
        if (i + S >= 32) {
            for (j = 0; j < n; j++) ++cnt[a[j] >> i];
            for (j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
            for (j = n - 1; j >= 0; j--) b[--cnt[a[j] >> i]] = a[j];
            u32 *tmp = a;
            a = b, b = tmp;
            continue;
        }
        u32 t = (1 << S) - 1;
        for (j = 0; j < n; j++) ++cnt[(a[j] >> i) & t];
        for (j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
        for (j = n - 1; j >= 0; j--) b[--cnt[(a[j] >> i) & t]] = a[j];
        u32 *tmp = a;
        a = b, b = tmp;
    }
    return a;
}

void Sorting_main() {
    int n;
    u32 seed;
    scanf("%d%u", &n, &seed);

    u32 *a = malloc(n * sizeof(u32));
    int i;
    for (i = 0; i < n; i++) {
        seed = next_integer(seed);
        a[i] = seed;
    }

    sort(a, n);

    output_arr(a, n * sizeof(u32));
}


inline u64 sqr(int x) {
    return x * (long long)x;
}

inline int get_min(const u64 *a, const int *list, int n) {
    int ret = list[0];
    u64 mi = a[ret];
    int _;
    for (_ = 0; _ + 1 <= n; _ += 1) {
        int i = list[_];
        if (a[i] < mi) mi = a[i], ret = i;
    }
    return ret;
}

u64 * sort_u64(u64 *a, int n) {
    const int S = 8;
    u64 *b = malloc(n * sizeof(u64));
    static u32 cnt[256];
    int i, j;
    for (i = 0; i < 64; i += S) {
        memset(cnt, 0, sizeof(cnt));
        if (i + S >= 64) {
            for (j = 0; j < n; j++) ++cnt[a[j] >> i];
            for (j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
            for (j = n - 1; j >= 0; j--) b[--cnt[a[j] >> i]] = a[j];
            u64 *tmp = a;
            a = b, b = tmp;
            continue;
        }
        u32 t = (1 << S) - 1;
        for (j = 0; j < n; j++) ++cnt[(a[j] >> i) & t];
        for (j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
        for (j = n - 1; j >= 0; j--) b[--cnt[(a[j] >> i) & t]] = a[j];
        u64 *tmp = a;
        a = b, b = tmp;
    }
    return a;
}

void get_MST(u64 *edge_len, int *x, int *y, int n) {
    u64 *min_dist = malloc(n * sizeof(u64));
    min_dist[0] = 0x3f3f3f3f3f3f3f3full;
    int i;
    for (i = 1; i < n; i++) {
        min_dist[i] = sqr(x[i] - x[0]) + sqr(y[i] - y[0]);
    }
    int *list = malloc(n * sizeof(int));
    int *poss = malloc(n * sizeof(int));
    for (i = 0; i < n; i++) {
        list[i] = poss[i] = i;
    }
    for (i = 1; i < n; i++) {
        int id = get_min(min_dist, list + i, n - i);
        edge_len[i - 1] = min_dist[id];
        min_dist[id] = 0x3f3f3f3f3f3f3f3full;
        int xid = x[id], yid = y[id];
        if (list[i] != id) {
            list[poss[id]] = list[i];
            poss[list[i]] = poss[id];
        }
        int _;
        for (_ = i + 1; _ < n; _++) {
            int j = list[_];
            u64 tmp_dist = sqr(x[j] - xid) + sqr(y[j] - yid);
            if (tmp_dist < min_dist[j]) {
                min_dist[j] = tmp_dist;
            }
        }
    }
}

void MST_main() {
    int n;
    scanf("%d", &n);

    int *x = malloc(n * sizeof(int));
    int *y = malloc(n * sizeof(int));
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d%d", x + i, y + i);
    }

    u64 *edge_len = malloc((n - 1) * sizeof(u64));

    get_MST(edge_len, x, y, n);
    edge_len = sort_u64(edge_len, n - 1);

    output_arr(edge_len, (n - 1) * sizeof(u64));
}


typedef struct {
    int x[5];
} Point;

inline void read_point(Point *a) {
    scanf("%d%d%d%d%d", a->x, a->x + 1, a->x + 2, a->x + 3, a->x + 4);
}

void sort_points(Point *a, int *b, int n, int cmp_id, int *cnt) {
    memset(cnt, 0, n * sizeof(int));
    int i;
    for (i = 0; i < n; i++) ++cnt[a[i].x[cmp_id]];
    for (i = 1; i < n; i++) cnt[i] += cnt[i - 1];
    for (i = n - 1; i >= 0; i--) b[--cnt[a[i].x[cmp_id]]] = i;
}

inline void set_bit(u32 *a, int x) {
    a[x >> 5] |= 1u << (x & 31);
}

inline void clear_bit(u32 *a, int x) {
    a[x >> 5] -= 1u << (x & 31);
}

int count_table[1 << 11];

void count_pre() {
    count_table[0] = 0;
    int i;
    for (i = 1; i < 1 << 11; i++) {
        count_table[i] = count_table[i >> 1] + (i & 1);
    }
}

inline int count_bits(u32 x) {
    return count_table[x >> 22] + count_table[(x >> 11) & 2047u] + count_table[x & 2047u];
    // x -= (x & 0xAAAAAAAAu) >> 1;
    // x = ((x & 0xCCCCCCCCu) >> 2) + (x & 0x33333333u);
    // x = ((x >> 4) + x) & 0x0F0F0F0Fu;
    // return (x * 0x01010101u) >> 24;
}

void solve(int n, int q, Point *a, Point *queries, u32 *anss) {
    int len = (n - 1) / 32 + 1;
    int *b = malloc(n * sizeof(int));
    int *_cnt = malloc(n * sizeof(int));
    u32 *all_sets[5];
    int *sorted_ids[5];
    int *ranks[5];
    u32 *set_now = malloc(n * sizeof(u32));

    int M = n / 15000 + 1;
    
    int i, j, k;
    for (i = 0; i < 5; i++) {
        sort_points(a, b, n, i, _cnt);
        sorted_ids[i] = malloc(n * sizeof(int));
        ranks[i] = malloc(n * sizeof(int));
        memcpy(sorted_ids[i], b, n * sizeof(int));

        u32 *sets = malloc((((n - 1) / M + 1) * len) * sizeof(u32));
        all_sets[i] = sets;

        memset(set_now, 0, len * sizeof(u32));

        int last = 0;
        for (j = 0; j < n; j++) {
            set_bit(set_now, b[j]);

            if (j % M == 0) {
                memcpy(sets + j / M * len, set_now, len * sizeof(u32));
            }

            int now = a[b[j]].x[i];
            while (last < now) ranks[i][last++] = j;
        }
        while (last < n) ranks[i][last++] = n;
    }

    count_pre();

    for (i = 0; i < q; i++) {
        anss[i] = -1;
        for (j = 0; j < 5; j++) {
            if (ranks[j][queries[i].x[j]] == 0) {
                anss[i] = 0;
            }
        }
        if (anss[i] == 0) continue;

        u32 *s[5];

        for (j = 0; j < 5; j++) {
            int rk = ranks[j][queries[i].x[j]] - 1;
            int set_id = rk / M;
            s[j] = all_sets[j] + set_id * len;
            u32 *tmp_set = s[j];
            int *ids = sorted_ids[j];
            for (k = set_id * M + 1; k <= rk; k++) {
                set_bit(tmp_set, ids[k]);
            }
        }

        u32 ans = 0;
        for (j = 0; j < len; j++) {
            ans += count_bits(s[0][j] & s[1][j] & s[2][j] & s[3][j] & s[4][j]);
        }
        anss[i] = ans;

        for (j = 0; j < 5; j++) {
            int rk = ranks[j][queries[i].x[j]] - 1;
            int set_id = rk / M;
            s[j] = all_sets[j] + set_id * len;
            u32 *tmp_set = s[j];
            int *ids = sorted_ids[j];
            for (k = set_id * M + 1; k <= rk; k++) {
                clear_bit(tmp_set, ids[k]);
            }
        }
    }
}

void Counting_main() {
    int n, q;
    scanf("%d%d", &n, &q);

    Point *a = malloc(n * sizeof(Point));
    int i;
    for (i = 0; i < n; i++) read_point(a + i);

    Point *queries = malloc(q * sizeof(Point));
    for (i = 0; i < q; i++) read_point(queries + i);

    u32 *anss = malloc(q * sizeof(u32));
    solve(n, q, a, queries, anss);

    output_arr(anss, q * sizeof(u32));
}


void add(u32 *a, int m) {
    int j = 0;
    for (; j + 4 <= m; j += 4) {
        u32 s0 = a[j] + a[j + 1];
        u32 s1 = a[j + 1] + a[j + 2];
        u32 s2 = a[j + 2] + a[j + 3];
        u32 s3 = a[j + 3] + a[j + 4];
        a[j] = s0;
        a[j + 1] = s1;
        a[j + 2] = s2;
        a[j + 3] = s3;
    }
    for (; j < m; j++) {
        a[j] += a[j + 1];
    }
}

inline u32 min(u32 x, u32 y) {
    return x < y ? x : y;
}

u32 solve_task4(int n, char *s) {
    u32 *dp = (u32 *)(malloc(((int)(1.5 * n) + 10) * sizeof(u32))) + (int)(n * 0.5) + 5;
    memset(dp, 0, n * sizeof(u32));
    dp[0] = 1;

    int i;
    for (i = 0; i < n; i++) {
        int m = min(i + 1, n - i - 1) / 2;

        if (s[i] == '(') {
            if (i % 2 == 1) {
                --dp;
                dp[0] = 0;
            }
        } else if (s[i] == ')') {
            if (i % 2 == 0) {
                ++dp;
            }
        } else {
            if (i % 2 == 0) {
                // 0 ~ m: += + 1
                add(dp, m + 1);
                dp[m + 1] = 0;
            } else {
                // 0 ~ m - 1: += +1
                // -1: = 0
                u32 tmp0 = dp[0];
                add(dp, m);
                dp[m] = 0;
                dp[-1] = tmp0;
                --dp;
            }
        }
    }

    return dp[0] * (n % 2 == 0);
}

void Parentheses_main() {
    int n;
    scanf("%d", &n);

    char *s = malloc((n + 1) * sizeof(char));
    scanf("%s", s);

    u32 ans;
    ans = solve_task4(n, s);

    printf("%u\n", ans);
}


int main() {
    int task_id;
    scanf("%d", &task_id);
    
    switch (task_id) {
        case 1:
            Sorting_main();
            break;
        case 2:
            MST_main();
            break;
        case 3:
            Counting_main();
            break;
        case 4:
            Parentheses_main();
            break;
    }
    
    return 0;
}
