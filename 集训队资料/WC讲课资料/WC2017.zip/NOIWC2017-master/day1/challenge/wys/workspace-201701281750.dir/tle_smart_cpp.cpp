#include <stdio.h>
#include <string.h>
#include <algorithm>

typedef unsigned int u32;
typedef unsigned long long u64;

inline u32 next_integer(u32 x) {
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

bool output_arr(void *a, u32 size) {
    if (size % 4) {
        return puts("-1"), 0;
    }
    
    u32 blocks = size / 4;
    u32 *A = (u32 *)a;
    u32 ret = size;
    u32 x = 23333333;
    for (u32 i = 0; i < blocks; i++) {
        ret = ret ^ (A[i] + x);
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    
    return printf("%u\n", ret), 1;
}

// ===== header ======


namespace Sorting {
    void init_data(u32 *a, int n, u32 seed) {
        for (int i = 0; i < n; i++) {
            seed = next_integer(seed);
            a[i] = seed;
        }
    }
    
    u32 * sort(u32 *a, int n) {
        const int S = 16;
        u32 *b = new u32[n];
        static u32 cnt[1 << S];
        for (int i = 0; i < 32; i += S) {
            memset(cnt, 0, sizeof(cnt));
            if (i + S >= 32) {
                for (int j = 0; j < n; j++) ++cnt[a[j] >> i];
                for (int j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
                for (int j = n - 1; j >= 0; j--) b[--cnt[a[j] >> i]] = a[j];
                u32 *tmp = a;
                a = b, b = tmp;
                continue;
            }
            u32 t = (1 << S) - 1;
            for (int j = 0; j < n; j++) ++cnt[(a[j] >> i) & t];
            for (int j = 1; j < 1 << S; j++) cnt[j] += cnt[j - 1];
            for (int j = n - 1; j >= 0; j--) b[--cnt[(a[j] >> i) & t]] = a[j];
            u32 *tmp = a;
            a = b, b = tmp;
        }
        return a;
    }
    
    void main() {
        int n;
        u32 seed;
        scanf("%d%u", &n, &seed);
        
        u32 *a = new u32[n];
        init_data(a, n, seed);
        
        a = sort(a, n);
        
        output_arr(a, n * sizeof(u32));
    }
}


namespace MST {
    
    inline u64 sqr(int x) {
        return x * (long long)x;
    }
    
    inline int get_min(const u64 *a, int n) {
        int ret = 0;
        for (int i = 1; i < n; i++) {
            if (a[i] < a[ret]) ret = i;
        }
        return ret;
    }
    
    void get_MST(u64 *edge_len, int *x, int *y, int n) {
        u64 *min_dist = new u64[n];
        min_dist[0] = 0x3f3f3f3f3f3f3f3full;
        for (int i = 1; i < n; i++) {
            min_dist[i] = sqr(x[i] - x[0]) + sqr(y[i] - y[0]);
        }
        for (int i = 1; i < n; i++) {
            int id = get_min(min_dist, n);
            edge_len[i - 1] = min_dist[id];
            min_dist[id] = 0x3f3f3f3f3f3f3f3full;
            for (int j = 1; j < n; j++) {
                if (min_dist[j] != 0x3f3f3f3f3f3f3f3full) {
                    u64 tmp_dist = sqr(x[j] - x[id]) + sqr(y[j] - y[id]);
                    if (tmp_dist < min_dist[j]) {
                        min_dist[j] = tmp_dist;
                    }
                }
            }
        }
        std::sort(edge_len, edge_len + n - 1);
    }
    
    void main() {
        int n;
        scanf("%d", &n);
        
        int *x = new int[n];
        int *y = new int[n];
        for (int i = 0; i < n; i++) {
            scanf("%d%d", x + i, y + i);
        }
        
        u64 *edge_len = new u64[n - 1];
        
        get_MST(edge_len, x, y, n);
        
        output_arr(edge_len, (n - 1) * sizeof(u64));
    }
}


namespace Counting {
    struct Point {
        int x[5];
    };
    
    inline void read_point(Point &a) {
        scanf("%d%d%d%d%d", a.x, a.x + 1, a.x + 2, a.x + 3, a.x + 4);
    }
    
    void sort_points(Point *a, int *b, int n, int cmp_id, int *cnt) {
        memset(cnt, 0, n * sizeof(int));
        for (int i = 0; i < n; i++) ++cnt[a[i].x[cmp_id]];
        for (int i = 1; i < n; i++) cnt[i] += cnt[i - 1];
        for (int i = n - 1; i >= 0; i--) b[--cnt[a[i].x[cmp_id]]] = i;
    }
    
    inline void set_bit(u32 *a, int x) {
        a[x >> 5] |= 1u << (x & 31);
    }
    
    int count_table[1 << 16];
    
    void count_pre() {
        count_table[0] = 0;
        for (int i = 1; i < 1 << 16; i++) {
            count_table[i] = count_table[i >> 1] + (i & 1);
        }
    }
    
    inline int count_bits(u32 x) {
        return count_table[x >> 16] + count_table[x & 65535u];
    }
    
    void solve(int n, int q, Point *a, Point *queries, u32 *anss) {
        int len = (n - 1) / 32 + 1;
        int *b = new int[n];
        int *_cnt = new int[n];
        u32 *all_sets[5];
        for (int i = 0; i < 5; i++) {
            sort_points(a, b, n, i, _cnt);
            u32 *sets = new u32[n * len];
            all_sets[i] = sets;
            u32 *set_now = sets;
            memset(set_now, 0, len * sizeof(u32));
            int k = 0;
            while (k < n && a[b[k]].x[i] == 0) set_bit(set_now, b[k]), ++k;
            for (int j = 1; j < n; j++) {
                set_now += len;
                memcpy(set_now, set_now - len, len * sizeof(u32));
                while (k < n && a[b[k]].x[i] == j) set_bit(set_now, b[k]), ++k;
            }
        }
        
        count_pre();
        
        for (int i = 0; i < q; i++) {
            u32 *s[5];
            for (int j = 0; j < 5; j++) {
                s[j] = all_sets[j] + queries[i].x[j] * len;
            }
            u32 ans = 0;
            for (int j = 0; j < len; j++) {
                ans += count_bits(s[0][j] & s[1][j] & s[2][j] & s[3][j] & s[4][j]);
            }
            anss[i] = ans;
        }
    }
    
    void main() {
        int n, q;
        scanf("%d%d", &n, &q);
        
        Point *a = new Point[n];
        for (int i = 0; i < n; i++) read_point(a[i]);
        
        Point *queries = new Point[q];
        for (int i = 0; i < q; i++) read_point(queries[i]);
        
        u32 *anss = new u32[q];
        solve(n, q, a, queries, anss);
        
        output_arr(anss, q * sizeof(u32));
    }
}


namespace Parentheses {
    u32 solve(int n, char *s) {
        u32 *dp = (new u32[(int)(2.5 * n) + 10]) + n;
        memset(dp, 0, n * sizeof(u32));
        dp[0] = 1;
        
        for (int i = 0; i < n; i++) {
            int m = std::min(i + 1, n - i);
            
            if (s[i] == '(') {
                // dp_now[0] = 0;
                // memcpy(dp_now + 1, dp_pre, m * sizeof(u32));
                --dp;
                dp[0] = 0;
            } else if (s[i] == ')') {
                // memcpy(dp_now, dp_pre + 1, m * sizeof(u32));
                // dp_now[m] = 0;
                ++dp;
                dp[m] = 0;
            } else {
                u32 tmp1 = dp[1];
                u32 tmp2 = dp[m - 1];
                int j = i % 2;
                for (; j + 1 <= m - 1; j += 2) {
                    dp[j] += dp[j + 2];
                    // dp[j + 1] += dp[j + 3];
                }
                // for (; j + 1 <= m - 1; j += 1) {
                //     dp[j] += dp[j + 2];
                // }
                --dp;
                dp[0] = tmp1;
                dp[m] = tmp2;
            }
        }
        
        return dp[0];
    }
    
    void main() {
        int n;
        scanf("%d", &n);
        
        char *s = new char[n + 1];
        scanf("%s", s);
        
        u32 ans;
        ans = solve(n, s);
        
        printf("%u\n", ans);
    }
}


int main() {
    int task_id;
    scanf("%d", &task_id);
    
    switch (task_id) {
        case 1:
            Sorting::main();
            break;
        case 2:
            MST::main();
            break;
        case 3:
            Counting::main();
            break;
        case 4:
            Parentheses::main();
            break;
    }
    
    return 0;
}
