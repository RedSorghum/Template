#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define bool int
#define true 1
#define false 0

typedef unsigned int u32;
typedef unsigned long long u64;

inline u32 next_integer(u32 x) {
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

bool output_arr(void *a, u32 size) {
    if (size % 4) {
        return puts("-1"), 0;
    }
    
    u32 blocks = size / 4;
    u32 *A = (u32 *)a;
    u32 ret = size;
    u32 x = 23333333;
    u32 i;
    for (i = 0; i < blocks; i++) {
        ret = ret ^ (A[i] + x);
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    
    return printf("%u\n", ret), 1;
}

// ===== header ======

void Sorting_main() {
    int n;
    u32 seed;
    scanf("%d%u", &n, &seed);

    u32 *a = malloc(n * sizeof(u32));
    int i;
    for (i = 0; i < n; i++) {
        seed = next_integer(seed);
        a[i] = seed;
    }

    // sort(a, n);

    output_arr(a, n * sizeof(u32));
}


void MST_main() {
    int n;
    scanf("%d", &n);

    int *x = malloc(n * sizeof(int));
    int *y = malloc(n * sizeof(int));
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d%d", x + i, y + i);
    }

    u64 *edge_len = malloc((n - 1) * sizeof(u64));

    // get_MST(edge_len, x, y, n);

    output_arr(edge_len, (n - 1) * sizeof(u64));
}


typedef struct {
    int x[5];
} Point;

inline void read_point(Point *a) {
    scanf("%d%d%d%d%d", a->x, a->x + 1, a->x + 2, a->x + 3, a->x + 4);
}

void Counting_main() {
    int n, q;
    scanf("%d%d", &n, &q);

    Point *a = malloc(n * sizeof(Point));
    int i;
    for (i = 0; i < n; i++) read_point(a + i);

    Point *queries = malloc(q * sizeof(Point));
    for (i = 0; i < q; i++) read_point(queries + i);

    u32 *anss = malloc(q * sizeof(u32));
    // solve(n, q, a, queries, anss);

    output_arr(anss, q * sizeof(u32));
}


void Parentheses_main() {
    int n;
    scanf("%d", &n);

    char *s = malloc((n + 1) * sizeof(char));
    scanf("%s", s);

    u32 ans;
    // ans = solve(n, s);

    printf("%u\n", ans);
}


int main() {
    int task_id;
    scanf("%d", &task_id);
    
    switch (task_id) {
        case 1:
            Sorting_main();
            break;
        case 2:
            MST_main();
            break;
        case 3:
            Counting_main();
            break;
        case 4:
            Parentheses_main();
            break;
    }
    
    return 0;
}
