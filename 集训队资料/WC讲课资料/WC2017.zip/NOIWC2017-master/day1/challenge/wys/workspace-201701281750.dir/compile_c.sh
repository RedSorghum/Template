gcc -m32 -O2 $1.c -o $1.exe -Wno-unused-result
