import re
import json

one = re.compile(r'^\D*(\d*)\D*$')
two = re.compile(r'^\D*(\d*)\D*(\d*)\D*$')
last_task = None

def get_args(args, task):
	global last_task
	if task is None:
		task = last_task
	m = one.match(args)
	if m:
		n = m.group(1)
		q = n if task == '3' else None
	else:
		m = two.match(args)
		n = m.group(1)
		q = m.group(2)
	last_task = task
	ret = {
		'task' : int(task),
		'n' : int(n),
	}
	if q:
		ret['q'] = int(q)
	return ret

if __name__ == '__main__':
	conf = json.loads(open('../prob.json', 'rb').read().decode('utf-8'))
	table = json.loads(open('../tables/data_range_ori.json', 'rb').read().decode('utf-8'))
	conf['data'] = [
		{
			'cases' : [int(datum[2])],
			'score' : int(datum[1]),
			'args' : get_args(datum[3], datum[0])
		} for idx, datum in enumerate(table)
	]
	conf['samples'] = conf['data']
	with open('../prob.json', 'wb') as f:
		f.write(json.dumps(conf, sort_keys = True, indent = 2).encode('utf-8'))