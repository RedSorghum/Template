#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <bitset>

typedef unsigned int lu;
typedef long long lld;
typedef unsigned long long llu;
const lld inf = 0x3F3F3F3F3F3F3F3FLL;

lu next_int(lu x){
	x ^= x << 13;
	x ^= x >> 17;
	return x ^= x << 5;
}

bool output_arr(void *inp, size_t size){
	if(size % 4)
		return printf("-1\n") && false;
	size_t count = size >> 2;
	lu *data = (lu*)inp;
	lu ret = size;
	lu x = 23333333u;
	for(size_t i = 0; i < count; i++){
		ret ^= data[i] + x;
		x = next_int(x);
	}
	return printf("%u\n", ret) || true;
}

namespace Sort{
	const int TOT_LEN = 32, BUFF_LEN = 8, ANDER = (1 << BUFF_LEN) - 1;
	lu *data, *next, seed, *buff[1 << BUFF_LEN];
	int n, cnt[1 << BUFF_LEN];
	int main(){
		scanf("%d%u", &n, &seed);
		data = new lu[n];
		next = new lu[n];
		for(int i = 0; i < n; i++)
			seed = data[i] = next_int(seed);
		for(int i = 0; i * BUFF_LEN < TOT_LEN; i++){
			int shrer = i * BUFF_LEN;
			memset(cnt, 0, sizeof(int) << BUFF_LEN);
			for(int j = 0; j < n; j++)
				cnt[data[j] >> shrer & ANDER]++;
			buff[0] = next - 1;
			for(int j = 0; j < ANDER; j++)
				buff[j + 1] = buff[j] + cnt[j];
			for(int j = 0; j < n; j++)
				*(++buff[data[j] >> shrer & ANDER]) = data[j];
			std::swap(data, next);
		}
		output_arr(data, n * 4);
		delete []data;
		delete []next;
		return 0;
	}
}

namespace MST{
	int n, *data;
	lld *dist;
	inline lld calc(int x, int y){
		return lld(x) * x + lld(y) * y;
	}
	
	int main(){
		scanf("%d", &n);
		data = new int[n * 2];
		dist = new lld[n];
		for(int i = 0; i < n; i++)
			scanf("%d%d", data + (i << 1), data + (i << 1 | 1));
		memset(dist, char(inf), sizeof(lld) * n);
		dist[0] = 0;
		for(int i = 0; i < n; i++){
			int cur_x = data[i << 1];
			int cur_y = data[i << 1 | 1];
			int best_ver = n;
			lld best_dist = inf;
			lld tmp;
			for(int j = i + 1; j < n; j++)
				if(best_dist > (dist[j] = tmp = std::min(dist[j], calc(data[j << 1] - cur_x, data[j << 1 | 1] - cur_y)))){
					best_ver = j;
					best_dist = tmp;
				}
			std::swap(dist[i + 1], dist[best_ver]);
			std::swap(data[i + 1 << 1], data[best_ver << 1]);
			std::swap(data[i + 1 << 1 | 1], data[best_ver << 1 | 1]);
		}
		std::sort(dist + 1, dist + n);
		output_arr(dist + 1, sizeof(lld) * (n - 1));
		delete []data;
		delete []dist;
		return 0;
	}
}


namespace Counting {
	const int N = 150000, K = 5;
	struct Point {
		bool type;
		int vec[K];
		int& operator[](int a){
			return vec[a];
		}
		const int& operator[](int a)const{
			return vec[a];
		}
	}*data;
	int dim, *order;
	typedef std::bitset<N> bs;
	bs *res;
	
	inline void read_point(Point &a) {
		for(int i = 0; i < K; i++)
			scanf("%d", &a[i]);
	}
	
	inline bool cmp(int a, int b){
		//printf("%d %d %d %d %d\n", a, b, data[a][dim], data[b][dim], data);
		if(data[a][dim] != data[b][dim])
			return data[a][dim] < data[b][dim];
		return data[a].type < data[b].type;
	}
	
	int main() {
		int n, m;
		scanf("%d%d", &n, &m);
		
		data = new Point[n + m];
		order = new int[n + m];
		res = new bs[m];
		
		for(int i = 0; i < n + m; i++)
			order[i] = i;
		
		for (int i = 0; i < n + m; i++){
			data[i].type = (i >= n);
			read_point(data[i]);
		}
		//printf("data = %d\n", data);
		
		for(dim = 0; dim < K; dim++){
			std::sort(order, order + n + m, cmp);
			/*for(int i = 0; i < n + m; i++)
				printf("%d ", order[i]);
			printf("\n");*/
			bs cur;
			for(int i = n + m - 1; i >= 0; i--)
				if(data[order[i]].type)
					res[order[i] - n] |= cur;
				else
					cur.set(order[i]);
		}
		
		lu *ans = new lu[m];
		for(int i = 0; i < m; i++)
			ans[i] = n - res[i].count();
		output_arr(ans, m * sizeof(lu));
		/*for(int i = 0; i < m; i++)
			printf("%d ", ans[i]);
		printf("\n");*/
		
		delete []data;
		delete []order;
		delete []res;
		delete []ans;
		
		return 0;
	}
}


int main(){
#ifndef __OI_TESTER__
	freopen("tle.in", "r", stdin);
	freopen("tle.out", "w", stdout);
#endif
	int task_id;
	scanf("%d", &task_id);
	switch(task_id){
		case 1:
			return Sort::main();
		case 2:
			return MST::main();
		case 3:
			return Counting::main();
	}
	
	return 0;
}
