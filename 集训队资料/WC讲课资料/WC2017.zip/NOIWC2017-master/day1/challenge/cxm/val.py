import json
import re
import math

inf = 1e100

class InputException(Exception):
	def __init__(self, value = ''):
		self.value = value
	def __str__(self):
		return '[E]At line %d : %s' % (line, repr(self.value))
		
def get_strs(f, num = None, split = ' '):
	global line
	line += 1
	items = f.readline().strip('\n').split(split)
	if num != None and len(items) != num:
		raise InputException('Must contain %d items, but %d get.%s' % (
			num,
			len(items),
			' May contain extra spaces at the end of the line.' if len(items) > num else ''
		))
	return items

def get_ints(f, num = None, split = ' '):
	items = get_strs(f, num, split)
	try:
		return list(map(int, items))
	except Exception as e:
		raise InputException(e)
		
def get_eof(f):
	global line
	line += 1
	extra = f.readline()
	if extra:
		raise InputException('Must get EOF but "%s" get.' % extra)

def check_equal(lef, rig, name_lef = None, name_rig = None):
	if lef != rig:
		raise InputException('%s must equal to %s, but %s and %s get.' % (
			('Variable ' + name_lef) if name_lef else str(lef),
			('Variable ' + name_rig) if name_rig else str(rig),
			str(lef),
			str(rig)
		))
		
def check_in(item, in_set, name = None):
	if item not in in_set:
		raise InputException('Variable%s must in %s, but %s get.' % (' "' + name + '"' if name else '', repr(in_set), repr(item)))
		
def check_re(item, r, name = None):
	if not r.match(item):
		raise InputException('Variable%s must match "%s", but %s get.' % (' "' + name + '"' if name else '', r.pattern, repr(item)))
		
def check_true(result, info = None):
	if not result:
		raise InputException(info if info else 'Expression must be True but False get.')

def is_prime(num):
	for i in range(2, num):
		if i * i > num:
			return True
		if num % i == 0:
			return False
	return True
		
def cant_split_to_2_pos_int_reciprocal(a):
	for i in range(2, int(math.sqrt(a + 1e-4)) if a > 100 else a):
		if a % i == 0 and (i % 6 != 1 or a / i % 6 != 1):
			return False
	return True

def task1(f, args):
	#n, a_n1 = get_ints(f, 2)
	n, = get_ints(f, 1)
	a_n1, = get_ints(f, 1)
	if args is None:
		check_in(n, range(1, 2 * 10 ** 8 + 1), 'n')
	else:
		check_equal(n, args['n'], 'n')
	check_in(a_n1, range(- 2 ** 31, 2 ** 31), 'a_-1')
	
def task2(f, args):
	n, = get_ints(f, 1)
	if args is None:
		check_in(n, range(1, 33000 + 1), 'n')
	else:
		check_equal(n, args['n'], 'n')
	for i in range(n):
		x, y = get_ints(f, 2)
		check_in(x, range(2 ** 30), 'x')
		check_in(y, range(2 ** 30), 'y')

def task3(f, args):
	n, q = get_ints(f, 2)
	if args is None:
		check_in(n, range(1, 150000 + 1), 'n')
		check_in(q, range(1, 200000 + 1), 'q')
	else:
		check_equal(n, args['n'], 'n')
		check_equal(q, args['q'], 'q')
	for i in range(n + q):
		pt = get_ints(f, 5)
		for j in range(5):
			check_in(pt[j], range(n), 'p[%d]' % j)
			
def task4(f, args):
	n, = get_ints(f, 1)
	if args is None:
		check_in(n, range(1, 266666 + 1), 'n')
	else:
		check_equal(n, args['n'], 'n')
	check_re(get_strs(f, 1)[0], re.compile(r'^[()?]{%d}$' % n))
	
def check(f, args = None):
	try:
		task = get_ints(f, 1)[0]
		if args is not None:
			check_equal(task, args['task'], 'task id')
		else:
			check_in(task, range(1, 4 + 1), 'task id')
		{
			1 : task1,
			2 : task2,
			3 : task3,
			4 : task4
		}[task](f, args)
		get_eof(f)
		print('Check succeeded.')
	except InputException as e:
		print(e)
		print('Check failed.')

if __name__ == '__main__':
	conf = json.loads(open('../prob.json', 'rb').read().decode('utf-8'))
	for i in range(conf['sample count']):
		with open('../down/%s%d.in' % (conf['name'], i + 1), 'r') as f:
			line = 0
			print('Checking sample %d' % (i + 1))
			check(f)
	for datum in conf['data']:
		for case in datum['cases']:
			print('Checking data %d' % case)
			try:
				with open('../data/%s%d.in' % (conf['name'], case), 'r') as f:
					line = 0
					check(f, datum['args'])
			except Exception as e:
				print('[E]Can\'t read input file.')
	if sum([datum['score'] for datum in conf['data']]) != 100:
		print('[W]Sum of score of all cases is not 100.')
